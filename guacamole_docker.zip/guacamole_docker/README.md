# Installation

## Pre-requisites

```
sudo yum update
sudo yum upgrade
sudo yum clean all
sudo yum makecache

# sudo yum install -y cairo-devel libjpeg-turbo-devel libjpeg-devel libpng-devel libtool libuuid-devel uuid-devel ffmpeg-devel freerdp-devel pango-devel libssh2-devel libtelnet-devel libvncserver-devel libwebsockets-devel pulseaudio-libs-devel openssl-devel libvorbis-devel libwebp-devel 
sudo yum install -y cairo-devel libjpeg-turbo-devel libjpeg-devel libpng-devel libtool libuuid-devel uuid-devel pango

wget https://apache.org/dyn/closer.lua/guacamole/1.5.3/source/guacamole-server-1.5.3.tar.gz?action=download
tar -xzf guacamole-server-1.5.3.tar.gz
cd guacamole-server-1.5.3/
./configure --with-init-dir=/etc/init.d
make
make install

sudo systemctl enable guacd
sudo systemctl start guacd
sudo systemctl status guacd

# Install client
tar -xzf guacamole-client-1.5.3.tar.gz
cd guacamole-client-1.5.3/
mvn package
```

```
docker run --name some-guacd -e GUACD_LOG_LEVEL=debug -d -p 4822:4822 guacamole/guacd
docker run --rm guacamole/guacamole /opt/guacamole/bin/initdb.sh --mysql > initdb.sql
docker run --rm guacamole/guacamole /opt/guacamole/bin/initdb.sh --postgresql > initdb.sql

docker-compose up -d --build
docker cp guacamole:/opt/guacamole/mysql/schema ./mysql_schema 
docker cp ./mysql_schema/ guacamole-db:/tmp
cat schema/*.sql | mysql -u root -p guacamole_db

Important database configuration link: https://guacamole.apache.org/doc/gug/jdbc-auth.html
```
